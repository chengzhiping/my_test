<template>
  <div class="input-row it-if">
    <label v-if="selectObj.selectPopup">{{ selectObj.selectTitle }}</label>
    <div v-if="selectObj.selectPopup" class="select-popup" :class="{active: selectObj.name}" @click="open">{{ selectObj.name || '请选择' }}</div>
    <div class="mongoliaLayer" v-show='isShow' @click="close"></div>
    <div class="mongoliaContent" :class="{mongoliaContentShow: layerShow, mongoliaContentHide: !layerShow}" v-show='isShow'>
      <div class="title">
        <span class="leftBtn" @click="close">取消</span>
        <span class="titleText">{{ selectObj.titleTip }}</span>
        <span class="rightBtn"@click="sure">确定</span>
      </div>
      <div class="picker-items">
        <div class="picker-slot picker-slot-center" style="flex: 1 1 0%; -webkit-box-flex: 1;">
          <div :class="{'picker-slot-wrapper': isMove}" style="height: 252px;" :style="{transform: 'translate(0px, ' + sliderHeight + 'px) translateZ(0px)'}" :id="selectObj.sliderId || 'slider'">
            <div class="picker-item" v-for="(item, index) in selectList" :class="{'picker-selected': item.value === selectValue}">{{ item.name }}</div>
          </div>
        </div>
        <div class="picker-center-highlight"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    /*
     *使用介绍
     *设置日期上限 selectObj.sliderId为自定义滑块ID，若同一页面（包括所有组件、子页面）同时引用下拉组件，则不可与默认值相同
     * 参数释义：
     * sliderId---用于区分滑块的DOM名称，便于控制（必传）
     * selectPopup---是否使用内置选择框    0/false/''/null... --- 不使用（非必传，默认为false）
     * titleTip---下拉框的标题（必传）
     * selectTitle---选择框前文案（selectPopup为TRUE时必传）
     * selectVal---默认选中项（必传）
     * name---选中项名称（selectPopup为TRUE时必传）
     */
    'selectObj': {
      type: Object,
      default: '',
      required: true
    },
    // 初始化默认显示日期
    'selectList': { // 下拉框数据渲染
      type: Array,
      default: '',
      required: true
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      // 子组件订阅事件
      subscribe: {
        // 选中的项
        SELECTITEM: 'confirm'
      },
      insurerBirthday: '',
      isShow: false,
      scrollTop: 0,
      // 显示选择开关
      layerShow: false,
      // 滑块滑动的第一个点坐标
      start: {},
      // 滑块滑动中的实时的一个点坐标
      move: {},
      // 滑块滑动的最后一个点坐标
      end: {},
      // 初始化滑块位子
      sliderHeight: 108,
      // 当前滑动总高度差
      sliderHeightY: 108,
      sliderHeightMax: 108,
      sliderHeightMin: 0,
      selectValue: 0,
      isMove: false
    }
  },
  created () {
    // 初始化展示
    this.setInit()
  },
  watch: {
    selectList: function (val, oldVal) {
      this.sliderHeight = 108
      this.sliderHeightY = 108
      this.sliderHeightMax = 108
      this.sliderHeightMin = 0
      this.selectValue = 0
      this.setInit()
    // },
    // isShow: function (val) {
    //   if (val) {
    //     this.scrollTop = document.body.scrollTop
    //     document.body.classList.add('bodyClass')
    //     document.body.style.top = this.scrollTop + 'px'
    //   } else {
    //     $(document.body).removeClass('bodyClass')
    //     document.body.scrollTop = this.scrollTop
    //   }
    }
  },
  mounted () {
    let me = this
    // 分块
    let el = document.getElementById(this.selectObj.sliderId || 'slider')
    // 监听touch事件
    el.addEventListener('touchstart', me.touchStart)
    el.addEventListener('touchmove', me.touchmMove)
    el.addEventListener('touchend', me.toucheEnd)
  },
  methods: {
    // 打开控件
    open () {
      if (this.disabled) return false
      var self = this
      this.isShow = true
      setTimeout(function () {
        self.layerShow = true
      }, 10)
    },
    // 关闭选择
    close (reset) {
      var self = this
      this.layerShow = false
      setTimeout(function () {
        self.isShow = false
        this.start = {}
        this.move = {}
        this.end = {}
      }, 300)
      if (reset !== true) {
        this.setInit()
      }
    },
    // 滑动开始
    touchStart (e) {
      this.isMove = false
      let c = e.touches[0]
      this.start = {
        x: c.clientX,
        y: c.clientY,
        time: Date.now()
      }
    },
    // 滑动中
    touchmMove (e) {
      let c = e.touches[0]
      this.move = {
        x: c.clientX - this.start.x,
        y: c.clientY - this.start.y,
        time: Date.now()
      }
      this.sliderHeight = this.sliderHeightY + this.move.y
    },
    // 滑动结束
    toucheEnd (e) {
      if (JSON.stringify(this.move) === '{}' || !this.selectList.length) return false
      this.isMove = true
      let c = e.changedTouches[0]
      this.end = {
        x: c.clientX - this.start.x,
        y: c.clientY - this.start.y,
        time: Date.now()
      }
      this.sliderHeightY += Math.round(this.move.y / 36) * 36
      if (this.sliderHeightY > this.sliderHeightMax) {
        this.sliderHeightY = this.sliderHeightMax
      } else if (this.sliderHeightY < this.sliderHeightMin) {
        this.sliderHeightY = this.sliderHeightMin
      }
      this.sliderHeight = this.sliderHeightY
      let value = 3 - this.sliderHeight / 36
      this.selectValue = this.selectList[value].value
      this.move = {}
    },
    // 初始化展示
    setInit () {
      let me = this
      for (let k in this.selectList) {
        if (this.selectList[k].value === me.selectObj.selectVal) {
          me.sliderHeight = (3 - k) * 36
          me.sliderHeightY = (3 - k) * 36
        }
      }
      this.selectValue = this.selectObj.selectVal
      me.sliderHeightMin = (4 - this.selectList.length) * 36
    },
    sure () {
      let value = 3 - this.sliderHeight / 36
      let selectObj = this.selectList[value]
      this.selectObj.name = selectObj.name
      this.close(true)
      this.$emit(this.subscribe.SELECTITEM, selectObj)
    }
  }
}
</script>

<style scoped>
  * {
    box-sizing: border-box;
  }
  .bodyClass {
    position: fixed;
    width: 100%;
  }
  .cs-input {
    width: 1.5rem;
    height: .5rem;
  }
  .mongoliaLayer {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 5000;
    background-color: rgba(0,0,0,.5);
  }
  .mongoliaContent {
    width: 100%;
    height: 292px;
    position: fixed;
    top: auto;
    left: 0;
    right: auto;
    bottom: 0;
    z-index: 5001;
    background-color: white;
    transform: translate3d(0,100%,0);
    transition: .2s ease-out;
    -moz-transition: .2s ease-out;
    -webkit-transition: .2s ease-out;
    -o-transition: .2s ease-out;
  }
  .mongoliaContentHide {
    transform: translate3d(0,100%,0);
  }
  .mongoliaContentShow {
    transform: translate3d(0,0,0);
  }
  .title {
    width: 100%;
    height: 40px;
    margin: 0;
    /*position: relative;
    top: 0;
    left: 0;
    z-index: 12;*/
    /*background-color: rgb(240,240,240);*/
    border-bottom: 1px #ccc solid;
    font-size: 16px;
  }
  .title span {
    display: inline-block;
    width: 25%;
    text-align: center;
    line-height: 40px;
    color: #26a2ff;
    margin: 0;
  }
  .title .titleText {
    float: left;
    width: 50%;
  }
  .title .leftBtn {
    float: left;
  }
  .title .rightBtn {
    float: right;
  }
  .picker-items {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    padding: 0;
    text-align: center;
    font-size: 24px;
    position: relative;
    top:40px;
  }
  .picker-slot .picker-slot-center {
    text-align: center;
    flex: 1 1 0%;
    -webkit-box-flex: 1;
  }
  .picker-slot {
      font-size: 18px;
      overflow: hidden;
      position: relative;
      max-height: 100%;
  }
  .picker-center-highlight {
    height: 40px;
    box-sizing: border-box;
    position: absolute;
    left: 0;
    width: 100%;
    top: 50%;
    margin-top: -20px;
    pointer-events: none;
  }
  .picker-center-highlight:before {
    left: 0;
    top: 0;
    bottom: auto;
    right: auto;
  }
  .picker-center-highlight:after {
    left: 0;
    bottom: 0;
    right: auto;
    top: auto;
  }
  .picker-center-highlight:after, .picker-center-highlight:before {
    content: '';
    position: absolute;
    height: 1px;
    width: 100%;
    background-color: #eaeaea;
    display: block;
    z-index: 5003;
    -webkit-transform: scaleY(.5);
    transform: scaleY(.5);
  }
  .picker-item.picker-selected {
    color: #000;
    -webkit-transform: translateZ(0) rotateX(0);
    transform: translateZ(0) rotateX(0);
  }
  .picker-item {
    height: 36px;
    line-height: 36px;
    padding: 0 10px;
    white-space: nowrap;
    position: relative;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #707274;
    left: 0;
    top: 0;
    width: 100%;
    box-sizing: border-box;
  }
  .picker-slot-wrapper {
    -webkit-transition-duration: .3s;
    transition-duration: .3s;
    -webkit-transition-timing-function: ease-out;
    transition-timing-function: ease-out;
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
  }
</style>