import Vue from 'vue'
import Router from 'vue-router'
import Order from '@/containers/order/Order'
import Me from '@/containers/me/me'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/order',
      name: 'order',
      component: Order
    },
    {
    	path: '/me',
    	name: 'me',
    	component: Me
    }
  ]
})
