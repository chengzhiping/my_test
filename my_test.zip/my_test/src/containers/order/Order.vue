<template>
  <div class='btn-wrap'>
    <!-- 点击触发selectPicker函数 -->
    <div class='btn-blue' @click='selectPicker'>点击调出选择国家组件</div>
    <br/>
    <div>您选择了：{{selectedcountry}}</div>
    <selectPicker ref='select' :selectObj='selectObj' :selectList='selectList' @confirm='selectedItem'></selectPicker>

  </div>
</template>
<script>
import SelectPicker from '@/components/SelectPicker'
export default {
  data () {
    return {
      // 下拉选项选中项
      selectObj: {
        titleTip: '',
        selectVal: ''
      },
      // 下拉选项数组
      selectList: [],
      selectedcountry: '',
      list: [
        {
          'country': 'VRC',
          'description': '中华人民共和国'
        }, {
          'country': '*ST',
          'description': '无国籍'
        }, {
          'country': 'A',
          'description': '奥地利'
        }, {
          'country': 'AFG',
          'description': '阿富汗'
        }, {
          'country': 'AG',
          'description': '安提瓜和巴布达'
        }, {
          'country': 'AL',
          'description': '阿尔巴尼亚'
        }, {
          'country': 'AND',
          'description': '安道尔'
        }, {
          'country': 'ANG',
          'description': '安哥拉'
        }, {
          'country': 'ARM',
          'description': '亚美尼亚'
        }, {
          'country': 'AUS',
          'description': '澳大利亚'
        }, {
          'country': 'B',
          'description': '比利时'
        }, {
          'country': 'BBY',
          'description': '巴布亚新几内亚'
        }, {
          'country': 'BD',
          'description': '孟加拉国'
        }
      ]
    }
  },
  methods: {
    // 点击后显示选项弹窗，预先将选项转义重新命名
    selectPicker () {
      // 点开后默认显示哪个国籍设置 （这里VRC指的是中国）
      this.selectObj = {
        titleTip: '国籍', // 弹窗中间的标题
        selectVal: 'VRC' // 初始化选中值
      }
      // 这里的this.list直接取得是data里面的，this.list可以是ajax请求回来的
      this.selectList = this.formartArr(this.list)
      this.$refs.select.open() // 触发SelectPicker组件中open函数
    },
    selectedItem (selectedObj) {
      console.log('您选择了：' + selectedObj.name)
      this.selectedcountry = selectedObj.name
    },
    // 转义数组
    formartArr (list = []) {
      let nationality = []
      list.forEach((v, i) => {
        nationality[i] = {}
        Object.keys(v).forEach((key) => {
          nationality[i].name = v.description
          nationality[i].value = v.country
        })
      })
      return nationality
    }
  },
  components: {
    SelectPicker
  }
}
</script>
<style>
  .btn-blue{
    width: 170px;
    height:40px;
    background:blue;
    color:white;
    border-radius:5px;
    line-height:40px;
    text-align:center;
  }
</style>