<template>
  <LoadMore :bottomMethod="loadMore"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" :bottomPullText="'释放查看更多'" :bottomDropText="'释放查看更多'" ref="loadmore" :bottomLoadingText="'正在帮亲奋力加载中......'">
    <ul class="list-wrap" id="container">
      <li v-for="item in mockData">我是内容{{item}}</li>
    </ul>
  </LoadMore>
</template>
<script>
import LoadMore from '@/components/LoadMore'
export default {
  data () {
    return {
      bottomStatus: '',
      allLoaded: false,
      mockData: 25
    }
  },
  methods: {
    topMethod (...rest) {
      console.log('111', rest)
    },
    handleBottomChange (status) {
      console.log('333', status)
      this.bottomStatus = status;
    },
    loadMore (...rest) {
      console.log('2222', rest)
      this.mockData += 10
      setTimeout(() => {
        this.$refs.loadmore.onBottomLoaded(this.$refs.loadmore.uuid);
      }, 3000)
    },
    mounred () {
      let $container = document.getElementById('container')
      $container.addEventListener('scroll', () => {
        console.log('scroll');
        if ($container.scrollTop + height > $listBox.offsetHeight + $detail.offsetHeight + $footer.offsetHeight + 15) {
          this.loadMore();
        }
      })
    }
  },
  components: {
    LoadMore
  }
}
</script>
<style>
  .list-wrap{
    width:100%;
  }
  .list-wrap li{
    width:100%;
    height:30px;
    background: yellow;
    line-height:30px;
    border-bottom:1px solid #ccc;
  }
  body, html{
    overflow-y: auto; 
  }
</style>