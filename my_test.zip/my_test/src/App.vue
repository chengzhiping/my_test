<template>
  <div id="app">
    <router-view></router-view>
    <nav class="tabs">
      <router-link v-for="(tab, index) in tabs" :key="index" :to="tab.path">{{tab.title}}</router-link>
    </nav>
  </div>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
      tabs: [
        {title: '外卖', path: '/home'},
        {title: '发现', path: '/discover'},
        {title: '订单', path: '/order'},
        {title: '我的', path: '/me'}
      ]
    }
  }
}
</script>

<style>
*{
  margin: 0;
  padding: 0;
}
a{
  text-decoration: none;
}
html, body, #app{
  width: 100%;
  height: 100%;
}
.tabs{
  width: 100%;
  height: 49px;
  position: absolute;
  left: 0;
  bottom: 0;
  display: flex;
}
.tabs:before{
  content: '';
  display: block;
  width: 100%;
  height: 1px;
  border-top: 1px solid #000;
  position: absolute;
  left: 0;
  top: -1px;
  transform: scaleY(0.5);
}
.tabs a{
  flex: 1;
  line-height: 49px;
  text-align: center;
  background: lightblue;
  color: #2C3E50;
}
.tabs a.router-link-active{
  background: lightsalmon;
}
#app .header{
  width: 100%;
  height: 44px;
  position: absolute;
  left: 0;
  top: 0;
  background: lightseagreen;
}
#app .header .title{
  width: 100%;
  height: 44px;
  line-height: 44px;
  text-align: center;
  font-size: 24px;
  color: #fff;
}
.left-btn, .right-btn{
  width: 50px;
  height: 34px;
  position: absolute;
  top: 5px;
  border: 1px solid #fff;
  border-radius: 5px;
  color: #fff;
  text-align: center;
  line-height: 34px;
}
.left-btn{
  left: 10px;
}
.right-btn{
  right: 10px;
} 
#app .content{
  width: 100%;
  position: absolute;
  top: 44px;
  bottom: 49px;
  background: #fff;
  z-index: 10;
}

</style>
